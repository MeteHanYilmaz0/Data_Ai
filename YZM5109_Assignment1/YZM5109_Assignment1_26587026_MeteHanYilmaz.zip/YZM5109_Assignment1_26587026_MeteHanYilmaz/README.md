# YZM5109 Assignment I · Option C: LoRA Fine-Tuning vs. Prompt Engineering

Mete Han Yılmaz · Student No. 26587026

**Research question:** does one LoRA fine-tuning run outperform prompting on the original model?

- **Model:** `Qwen/Qwen2.5-1.5B-Instruct`
- **Dataset:** `openai/gsm8k` (config `main`). Train has 7,473 problems and is used only for C4. There is no validation split. Test has 1,319 problems, all used.
- **Hardware:** 1x NVIDIA A100-40GB on Google Colab, bf16, seed 42.

| Condition | n | Accuracy (%) | 95% CI | Answer validity (%) | Mean tokens |
|---|---|---|---|---|---|
| C1 Zero-shot direct | 1319 | 70.9 | 68.4–73.3 | 96.5 | 217 |
| C2 Zero-shot CoT | 1319 | **75.4** | 73.0–77.7 | 95.6 | 278 |
| C3 PAL | 1319 | 59.7 | 57.0–62.4 | 92.6 | 110 |
| C4 LoRA (r=16, α=32) + direct prompt | 1319 | 59.6 | 56.9–62.2 | 99.4 | 95 |

## Contents

| Path | Content |
|---|---|
| `report/YZM5109_A1_Report_26587026.pdf` | IEEE two-column report, with LaTeX source |
| `AI_Usage_Log_26587026.pdf` | AI usage log |
| `code/YZM5109_A1_OptionC.ipynb` | Self-contained Colab notebook that runs all four conditions and the LoRA training |
| `code/src/a1lib.py` | Prompts, answer parsing, PAL executor, LoRA training loop, statistics. The notebook embeds this file. |
| `code/evaluate.py` | Recomputes every metric from the predictions and writes the CSV files |
| `code/analysis/deep_analysis.py` | Arithmetic-error, problem-length and complementarity analysis |
| `code/tests/smoke_test.py` | CPU end-to-end test with a tiny random model |
| `configs/` | Exact prompts and every experiment setting: decoding, LoRA, parsing, hardware |
| `predictions/` | One CSV per condition with sample_id, condition, prediction, reference, correctness and the raw model output, plus `predictions_all.json` |
| `metrics/` | Metric tables, McNemar tests, training statistics, post-hoc analysis |
| `screenshots/` | Labeled screenshot of the computed evaluation scores for each condition |
| `figures/` | All figures |

`sample_id` is the row index in the GSM8K test split.

## Reproduce

1. Open `code/YZM5109_A1_OptionC.ipynb` in Google Colab with an A100 or L4 GPU.
2. Select `Run all`. The default settings are the reported experiment.
3. To recompute the metrics, run the evaluation script on a folder with the per-condition `.jsonl` files that the notebook writes:

```
python code/evaluate.py <results_dir>
```

Software: PyTorch 2.11, Transformers 5.22.1, PEFT 0.21.2, Datasets 5.1.0.
